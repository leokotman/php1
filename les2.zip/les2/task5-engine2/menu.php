<a href="index.php">Главная</a>
<a href="about.php">О нас</a> <br>
