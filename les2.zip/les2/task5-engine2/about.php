<?php
//include "menu.php";
//?>
About
"A diploma is not a guarantee" or
" How did I get here"
I have come to programming after trying to find my place in music, diplomacy, psychology.
My goal
To become a professional in web-development, work remotely with pleasure.
Help on my way
I am grateful to my wife, mother and grandmother for supporting me on this journey.